-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Agu 2025 pada 04.38
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simaksi_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftaran_simaksi`
--

CREATE TABLE `pendaftaran_simaksi` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `identitas` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `tanggal_kegiatan` date DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `tujuan` text DEFAULT NULL,
  `waktu_daftar` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pendaftaran_simaksi`
--

INSERT INTO `pendaftaran_simaksi` (`id`, `nama`, `identitas`, `email`, `telepon`, `tanggal_kegiatan`, `lokasi`, `tujuan`, `waktu_daftar`) VALUES
(1, 'rifan', '30391757153', 'admin@example.com', '08212183713', '2025-08-07', 'Taman Nasional Merbabu', 'penelitian', '2025-08-07 02:01:26'),
(2, 'sulis', '20202030331', 'aidi@gmail.com', '0939732982', '2025-08-15', 'Taman Nasional Gunung Ciremai', 'penelitian', '2025-08-07 02:23:37'),
(3, 'sulis', '20202030331', 'aidi@gmail.com', '0939732982', '2025-08-15', 'Taman Nasional Gunung Ciremai', 'penelitian', '2025-08-07 02:34:15');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pendaftaran_simaksi`
--
ALTER TABLE `pendaftaran_simaksi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pendaftaran_simaksi`
--
ALTER TABLE `pendaftaran_simaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
