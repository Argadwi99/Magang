<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}
include '../db-connect.php';

$sql = "SELECT id, page_slug, section_id, title, content FROM web_content";
$result = $conn->query($sql);
$contents = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $contents[] = $row;
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Kelola Konten - Admin Dashboard</title>
    <link rel="icon" type="image/png" href="../img/logo2.png" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <style>
        .admin-dashboard {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .admin-header {
            padding: 20px;
            background-color: #006400;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-content {
            flex-grow: 1;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-dashboard">
        <div class="admin-header">
            <h2>Dashboard Admin</h2>
            <div>
                Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!
                <a href="../logout.php" class="btn btn-sm btn-light ms-3">Logout</a>
            </div>
        </div>
        <div class="admin-content">
            <div class="container">
                <h1 class="h4 text-primary mb-4">Kelola Konten Website</h1>
                <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                    <div class="alert alert-success">Konten berhasil diperbarui!</div>
                <?php endif; ?>
                <div class="card p-4 shadow-sm">
                    <form action="proses-edit-content.php" method="post">
                        <?php foreach ($contents as $item): ?>
                            <div class="mb-4 border-bottom pb-3">
                                <label for="title_<?php echo $item['id']; ?>" class="form-label fw-bold">Judul (<?php echo htmlspecialchars($item['page_slug'] . ' - ' . $item['section_id']); ?>)</label>
                                <input type="text" class="form-control" id="title_<?php echo $item['id']; ?>" name="content[<?php echo $item['id']; ?>][title]" value="<?php echo htmlspecialchars($item['title']); ?>">
                                
                                <label for="content_<?php echo $item['id']; ?>" class="form-label mt-2">Isi Konten</label>
                                <textarea class="form-control" id="content_<?php echo $item['id']; ?>" name="content[<?php echo $item['id']; ?>][content]" rows="5"><?php echo htmlspecialchars($item['content']); ?></textarea>
                            </div>
                        <?php endforeach; ?>
                        <button type="submit" class="btn btn-primary mt-3">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>