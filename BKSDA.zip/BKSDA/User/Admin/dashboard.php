<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Balai Konservasi Sumber Daya Alam - Admin Dashboard</title>
    <link rel="icon" type="image/png" href="../img/logo2.png" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <style> /* CSS kustom Anda */ </style>
</head>
<body>
    <div class="admin-dashboard">
        <div class="admin-header">
            <h2>Dashboard Admin</h2>
            <div>
                Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!
                <a href="../logout.php" class="btn btn-sm btn-light ms-3">Logout</a>
            </div>
        </div>
        <div class="admin-content">
            <div class="container">
                <div class="card p-4 shadow-sm">
                    <h1 class="h4 text-primary">Selamat Datang di Halaman Admin</h1>
                    <p class="text-muted">Di sini Anda bisa mengelola seluruh data dan konten website BKSDA Jawa Tengah.</p>
                </div>
                <div class="row g-4 mt-3">
                    <div class="col-lg-4">
                        <div class="card card-menu p-4 h-100 shadow-sm text-center">
                            <i class="fas fa-edit fa-4x text-primary mb-3"></i>
                            <h5 class="fw-bold">Kelola Konten Website</h5>
                            <p class="text-muted">Edit konten dinamis seperti Visi, Misi, dan Sejarah.</p>
                            <a href="edit-content.php" class="btn btn-primary mt-auto">Masuk</a>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card card-menu p-4 h-100 shadow-sm text-center">
                            <i class="fas fa-users-cog fa-4x text-primary mb-3"></i>
                            <h5 class="fw-bold">Kelola Pengguna</h5>
                            <p class="text-muted">Tambahkan, ubah, atau hapus data pengguna dan admin.</p>
                            <a href="#" class="btn btn-primary mt-auto">Masuk</a>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card card-menu p-4 h-100 shadow-sm text-center">
                            <i class="fas fa-newspaper fa-4x text-primary mb-3"></i>
                            <h5 class="fw-bold">Kelola Berita & Artikel</h5>
                            <p class="text-muted">Perbarui berita dan artikel terbaru di halaman website.</p>
                            <a href="#" class="btn btn-primary mt-auto">Masuk</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>